
package com.sunsoft.eclipselink.DAO;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.sunsoft.eclipselink.bean.Author1;

public class AuthorService 
{

	static EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("Eclipselink_JPA");
	static EntityManager entitymanager = emfactory.createEntityManager();
	
	public static void main(String[] args) 
	{
		AuthorService crud_serviceObj = new AuthorService();
		Author1 authorObj = new Author1();
		authorObj.setAid(1001);
		authorObj.setFname("Ankit");
		authorObj.setMname("Singh");
		authorObj.setLname("Chauhan");
		authorObj.setPno(123456789);
		crud_serviceObj.InsertIntoAuthorDB(authorObj);
		
		Author1 authorObj1 = new Author1();
		authorObj1.setAid(1002);
		authorObj1.setFname("Raju");
		authorObj1.setMname("Kumar");
		authorObj1.setLname("Gupta");
		authorObj1.setPno(2135666789);
		crud_serviceObj.InsertIntoAuthorDB(authorObj1);
		
		crud_serviceObj.UpdateAuthor(1001, "Anuja");
		System.out.println("Author record updated successfully");
		
		crud_serviceObj.deleteAuthorData(1002);
		System.out.println("Author record deleted successfully");	
		
	}

	void InsertIntoAuthorDB(Author1 authorObj) 
	 {
		entitymanager.getTransaction().begin();
		entitymanager.persist(authorObj);
		entitymanager.getTransaction().commit();	
	}
	void UpdateAuthor(int aid, String fname)
	{
		entitymanager.getTransaction().begin();
		Author1 author = entitymanager.find(Author1.class, aid);
		author.setFname(fname);
		entitymanager.getTransaction().commit();
	}
	 
	  void deleteAuthorData(int aid) 
	  {
		  entitymanager.getTransaction().begin();
			Author1 author = entitymanager.find(Author1.class,aid);
			entitymanager.remove(author);
			entitymanager.getTransaction().commit();
			
		}

}