package com.sunsoft.eclipselink.bean;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Table

public class Author1
{
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	private int aid;
	private String fname;
	private String mname;
	private String lname;
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public double getPno() {
		return pno;
	}
	public void setPno(double pno) {
		this.pno = pno;
	}
	private double pno;
	
	public Author1() {
		super();
	}
	public Author1(int aid, String fname, String mname, String lname, double pno) {
		super();
		this.aid = aid;
		this.fname = fname;
		this.mname = mname;
		this.lname = lname;
		this.pno = pno;
	}
}

