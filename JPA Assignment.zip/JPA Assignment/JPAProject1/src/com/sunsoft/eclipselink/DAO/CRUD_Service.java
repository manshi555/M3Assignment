package com.sunsoft.eclipselink.DAO;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.sunsoft.eclipselink.bean.Employee;


public class CRUD_Service 
{
	static EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("Eclipselink_JPA");
	static EntityManager entitymanager = emfactory.createEntityManager();
	public static void main(String args[])
	{
		CRUD_Service crud_serviceObj = new CRUD_Service();
		
		Employee employeeObj = new Employee();
		employeeObj.setEid(1000);
		employeeObj.setEname("Monty");
		employeeObj.setSalary(50000);
		employeeObj.setDeg("Technical Manager");
		crud_serviceObj.InsertIntoEmployeeDB(employeeObj);
		
		Employee employeeObj1 = new Employee();
		employeeObj1.setEid(1001);
		employeeObj1.setEname("Sanju");
		employeeObj1.setSalary(65000);
		employeeObj1.setDeg("Technical Lead");
		crud_serviceObj.InsertIntoEmployeeDB(employeeObj1);
		
		
		crud_serviceObj.UpdateEmployee(1000, 63000);
		System.out.println("Employee record updated successfully");
		
		crud_serviceObj.deleteEmployeeData(1001);
		System.out.println("Employee record deleted successfully");	
		
	}
	
	void InsertIntoEmployeeDB(Employee employeeObj)
	{
		entitymanager.getTransaction().begin();
		entitymanager.persist(employeeObj);
		entitymanager.getTransaction().commit();
	}
	
	void UpdateEmployee(int id, int salary)
	{
		entitymanager.getTransaction().begin();
		Employee employee = entitymanager.find(Employee.class, id);
		employee.setSalary(salary);
		entitymanager.getTransaction().commit();
	}
	
	void deleteEmployeeData(int id)
	{
		entitymanager.getTransaction().begin();
		Employee employee = entitymanager.find(Employee.class,id);
		entitymanager.remove(employee);
		entitymanager.getTransaction().commit();
		
	}
}
