package com.sunsoft.SpringBootRestWithException.Exception;
import org.springframework.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler ({InvalidProductIdException.class , InvalidProductNameException.class})
	public ResponseEntity<String> handleExceptions (Exception ex)
	{
		if(ex instanceof InvalidProductIdException )
		{
			HttpStatus status = HttpStatus.NOT_FOUND;
			return new ResponseEntity ("Invalid Product Id",status);
		}
		else if(ex instanceof InvalidProductNameException)
		{
			HttpStatus status = HttpStatus.NOT_FOUND;
			return new ResponseEntity ("Invalid Product Name",status);
		}
		else
			return null;
	}
}
