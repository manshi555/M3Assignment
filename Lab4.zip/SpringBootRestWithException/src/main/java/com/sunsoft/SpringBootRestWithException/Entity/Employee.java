package com.sunsoft.SpringBootRestWithException.Entity;

public class Employee {

}
