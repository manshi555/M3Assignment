package com.sunsoft.SpringBootRestWithException.Controller;

import org.springframework.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.sunsoft.SpringBootRestWithException.Exception.InvalidProductIdException;
import com.sunsoft.SpringBootRestWithException.Exception.InvalidProductNameException;



@RestController
public class EmployeeController {
	
	@GetMapping (path="/isValid",produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> index(@RequestParam ("ProductId") int ProductId,
			@RequestParam("name") String name) throws InvalidProductIdException, InvalidProductNameException{
		
		String strValidProduct=new String();
		if(ProductId == 0) {
			throw new InvalidProductIdException ("Exception : invalid product");
		 }
		else {
			strValidProduct="Valid Product";
		}
		System.out.println("Name Value is:"+name);
		
		if(name.equals(""))
			throw new InvalidProductNameException("Invalid Product name");     
		return new ResponseEntity<>(strValidProduct, HttpStatus.OK);
	}
	/*Test local exception Handling with
	 * 
	 * http://localhost:8080/isValid?ProductId=0&name=SamsungTv--> This will give InvalidProductException..

	@ExceptionHandler(InvalidProductIdException.class)
	 public ResponseEntity<String> handleException(Exception ex)
	 {
		return new ResponseEntity<> (ex.getMessage(), HttpStatus.NOT_FOUND);
	 }
	 	 */

}
