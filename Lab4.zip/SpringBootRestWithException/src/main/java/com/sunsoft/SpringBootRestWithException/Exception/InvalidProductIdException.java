package com.sunsoft.SpringBootRestWithException.Exception;
import org.springframework.http.*;

public class InvalidProductIdException extends Exception
{
	
	public  InvalidProductIdException(String str) 
	{
		super (str);
	}
}
