package com.sunsoft.SpringBootRestWithException.Exception;

import org.springframework.http.*;
public class InvalidProductNameException extends Exception{
	
	public InvalidProductNameException(String str)
	{
		super (str);
	}

}
