package com.sunsoft.SpringBootRestWithException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestWithExceptionApplicationTests {

	@Test
	void contextLoads() {
	}

}
