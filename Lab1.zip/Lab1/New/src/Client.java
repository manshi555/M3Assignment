
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class Client 
{

	public static void main(String[] args) 
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("helloBean.xml");
		Employee obj = (Employee) context.getBean("hello");
		System.out.println("Manshi Rathore");
		System.out.println("Here are the Employee Details");
		System.out.println("Employee Id is " +obj.getEmpId());
		System.out.println("Employee Name is " +obj.getName());	
		System.out.println("Employee Designation is " +obj.getDesignation());
		System.out.println("Employee Department is " +obj.getDept());
		
		
		
	}

}
